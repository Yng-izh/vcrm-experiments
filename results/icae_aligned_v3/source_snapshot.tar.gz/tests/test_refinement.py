import json

import pytest
import torch

from vcrm.codec import SlotCodec, VersionMarkers
from vcrm.io import file_digest
from vcrm.refinement import conflicting, fixed_train_pairs, selected_episodes, train_diagnostic
from vcrm.training import contrastive_margin, cosine_warmup_factor, mean_answer_logprob, temporal_pairs
from test_slots import episode


def test_margin_excludes_eos_normalizes_length_and_has_gradients():
    correct = torch.zeros(1, 3, 5, requires_grad=True)
    wrong = torch.zeros(1, 2, 5, requires_grad=True)
    target = torch.tensor([[1, 2, 4]])
    score = mean_answer_logprob(correct, target)
    torch.testing.assert_close(score, mean_answer_logprob(wrong, torch.tensor([[1, 4]])))
    loss = contrastive_margin(score, mean_answer_logprob(wrong, torch.tensor([[1, 4]])), 1.5)
    loss.backward()
    assert correct.grad[0, -1].abs().sum() == 0
    assert correct.grad[0, 0, 1] < 0
    assert wrong.grad[0, 0, 1] > 0
    assert contrastive_margin(torch.tensor(0.), torch.tensor(-2.), 1.5) == 0


def test_dropout_zeroes_whole_decoder_slots_only_and_is_eval_disabled():
    torch.manual_seed(7)
    d = SlotCodec(8, 2, 4, 2, True, .5)
    old, anchor = torch.randn(4, 8), torch.ones(128, 8)
    seen = []
    handle = d.recover.register_forward_pre_hook(lambda module, args: seen.append(args[1].detach().clone()))
    state = torch.random.get_rng_state().clone()
    encoded = d.encode(old, anchor)
    d.decode(encoded, anchor).sum().backward()
    assert torch.equal(state, torch.random.get_rng_state())
    base = seen[-1][0, :128]
    assert set(base.flatten().tolist()) == {0., 1.}
    assert ((base == 0).all(-1) | (base == 1).all(-1)).all()
    d.eval()
    d.decode(encoded.detach(), anchor)
    assert torch.equal(seen[-1][0, :128], anchor)
    torch.testing.assert_close(encoded, d.encode(old, anchor))
    handle.remove()
    with pytest.raises(ValueError, match='dropout'):
        SlotCodec(8, 2, 4, 2, True, 1.)


def test_cosine_warmup_and_fixed_train_selection():
    values = [cosine_warmup_factor(s, 100, 5) for s in range(101)]
    assert values[0] == .2 and values[4] == 1. and values[-1] == 0.
    assert values[10] > values[50] > values[90]
    pairs = temporal_pairs([episode()])
    # Existing fixture includes a shared alias, so it must not count as disjoint conflict.
    with pytest.raises(ValueError, match='only 0'):
        fixed_train_pairs(pairs, 1, 42)
    assert not conflicting(['The club'], ['club'])
    for p in pairs:
        p['historical']['answers'] = ['old']
        p['latest']['answers'] = ['new']
    assert [p['id'] for p in fixed_train_pairs(pairs, 1, 42)] == [p['id'] for p in fixed_train_pairs(pairs[::-1], 1, 42)]


def test_final_current_train_diagnostic_does_not_change_optimizer_pairs():
    source = episode()
    for q in source['queries']:
        q['answers'] = ['new' if q['latest'] else 'old']
    source['queries'][-1]['latest'] = False
    source['queries'].append(source['queries'][-1] | {'id': 's:2020', 'latest': True,
                            'time': '2020-01-01T00:00:00', 'as_of': '2020-01-01T00:00:00'})
    pairs = temporal_pairs([source], 3)
    before = json.dumps(pairs, sort_keys=True)
    selected = fixed_train_pairs(pairs, 2, 42, [source])
    assert all(p['latest']['latest'] for p in selected)
    assert all(p['current']['id'] == 's:6' for p in selected)
    assert before == json.dumps(pairs, sort_keys=True)


def test_selection_preserves_all_events_and_rejects_mismatched_data(tmp_path):
    episodes = [episode('val')]
    folder = tmp_path / 'prepared'
    folder.mkdir()
    data = folder / 'templama_val.json'
    data.write_text(json.dumps(episodes))
    manifest = tmp_path / 'selection.json'
    manifest.write_text(json.dumps({'split': 'val', 'data_sha256': file_digest(data), 'query_ids': ['s:1']}))
    cfg = {'data_root': str(tmp_path), 'evaluation_query_manifest': str(manifest)}
    selected = selected_episodes(cfg, episodes, 'val')
    assert len(selected[0]['events']) == 7
    assert [q['id'] for q in selected[0]['queries']] == ['s:1']
    data.write_text('[]')
    with pytest.raises(ValueError, match='mismatch'):
        selected_episodes(cfg, episodes, 'val')


def test_train_diagnostic_restores_modes_and_disables_dropout():
    class Reader:
        def answer(self, query, bundle):
            assert not d.training
            return {'answer': 'new'}
    d = SlotCodec(8, 2, 4, 2, True, .25)
    markers = VersionMarkers(8)
    pair = temporal_pairs([episode()])[0]
    pair['historical']['answers'], pair['latest']['answers'] = ['old'], ['new']
    result = train_diagnostic(Reader(), d, markers, lambda e: torch.ones(4, 8), [pair])
    assert result['stale_answer'] == 1 and result['f1'] == 0
    assert d.training and markers.training
