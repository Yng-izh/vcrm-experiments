from pathlib import Path

import pytest
import torch

from vcrm.data import ingestion_view
from vcrm.features import check, finalize, load, prepare, save
from vcrm.io import read_json, write_json


def fixture_config(tmp_path):
    checkpoint = tmp_path / 'checkpoint'
    checkpoint.write_bytes(b'test')
    event = {'id': 'v1', 'state_key': 's', 'time': '2020-01-01T00:00:00', 'text': 'A fact', 'key_text': 'A _X_'}
    episode = {'id': 'episode', 'events': [event], 'queries': [{'answers': ['gold']}], 'split': 'train'}
    config = {'checkpoint': str(checkpoint), 'model_revision': 'revision', 'icae_source_sha256': 'source',
              'feature_root': str(tmp_path / 'features'), 'data_root': str(tmp_path)}
    write_json(tmp_path / 'prepared/templama_train.json', [episode])
    return config, episode, event


def test_feature_cache_label_free_roundtrip_and_complete_gate(tmp_path):
    config, episode, event = fixture_config(tmp_path)
    prepare(config, 'train')
    with pytest.raises(RuntimeError, match='incomplete'):
        check(config, 'train')
    memory = torch.ones(128, 4096).half()
    save(config, 'train', episode['id'], event, memory)
    assert torch.equal(load(config, 'train', episode['id'], event), memory)
    metadata = list((Path(config['feature_root']) / 'train/events').glob('*.json'))[0].read_text()
    assert 'gold' not in metadata
    finalize(config, 'train')
    assert check(config, 'train')['complete']
    with pytest.raises(ValueError, match='immutable'):
        save(config, 'train', episode['id'], event, memory + 1)
    with pytest.raises(ValueError, match='identity'):
        load(config, 'train', episode['id'], event | {'text': 'changed'})


def test_feature_cache_rejects_shape_overflow_and_reader_changes(tmp_path):
    config, episode, event = fixture_config(tmp_path)
    prepare(config, 'train')
    for value in (torch.zeros(16, 4096), torch.full((128, 4096), 1e10)):
        with pytest.raises(ValueError):
            save(config, 'train', episode['id'], event, value)
    with pytest.raises(ValueError, match='different reader'):
        check(config | {'model_revision': 'new'}, 'train', False)


def test_suite_gpu_partition_and_immutable_configs(tmp_path):
    from run_paper import Suite, baseline_allocation
    assert baseline_allocation([0, 2, 3, 4, 5, 7, 9]) == ([0, 2, 3, 4], [5, 7, 9])
    assert baseline_allocation([9]) == ([9], [])
    suite = Suite({'run_prefix': 'test'}, tmp_path, {'seed': 42})
    path = suite.derived('official', slots=128)
    assert read_json(path)['slots'] == 128
    with pytest.raises(RuntimeError, match='changed'):
        suite.derived('official', slots=16)


def test_report_never_invents_unrun_results(tmp_path):
    from vcrm.paper_report import report
    value = report({'output_root': str(tmp_path)}, {'run_prefix': 'test', 'history_slots': [16, 32]}, tmp_path)
    assert value['splits']['test']['methods'] == []
    assert 'NA' in (tmp_path / 'table1.md').read_text()
    assert not (tmp_path / 'figure1.png').exists()


def test_explicit_failed_gate_override_preserves_identity_and_completeness(tmp_path):
    from vcrm.io import file_digest
    from vcrm.training import validate_codec_gate
    folder = tmp_path / 'gate'
    summary = {'complete': True, 'scope': 'validation'}
    gate = {'decision': 'hold_replace_or_fix_icae_checkpoint'}
    config = {'output_root': str(tmp_path), 'codec_gate_run': 'gate', 'model_revision': 'fixture'}
    write_json(folder / 'summary.json', summary)
    write_json(folder / 'gate.json', gate)
    reader = Path(__file__).parents[1] / 'vcrm/reader.py'
    write_json(folder / 'manifest.json', {'config': config, 'encoder_weights': {},
                                        'code': {'vcrm/reader.py': file_digest(reader)}})
    with pytest.raises(RuntimeError):
        validate_codec_gate(config | {'codec_manual_review_approved': True})
    override = tmp_path / 'override.json'
    write_json(override, {'explicit_user_authorization': True, 'authorization_note': 'Human explicitly directs C/D despite gate failure',
                         'gate_run': 'gate', 'summary_sha256': file_digest(folder / 'summary.json'),
                         'gate_sha256': file_digest(folder / 'gate.json'), 'original_decision': gate['decision']})
    config['codec_gate_override'] = str(override)
    validate_codec_gate(config)
    with pytest.raises(RuntimeError, match='different reader'):
        validate_codec_gate(config | {'model_revision': 'changed'})
    assert read_json(folder / 'gate.json') == gate
    write_json(folder / 'summary.json', summary | {'complete': False})
    with pytest.raises(RuntimeError, match='Partial'):
        validate_codec_gate(config)
