import torch
import pytest

from vcrm.codec import SlotCodec, VersionMarkers
from vcrm.index import SemanticIndex
from vcrm.io import write_json, read_json, row_path
from vcrm.runtime import SlotMemoryRuntime
from vcrm.store import CurrentSnapshotStore
from test_slots import episode


@pytest.mark.parametrize('conditioned', [False, True])
def test_snapshot_evaluation_ingests_all_events_and_counts_current_only_once(tmp_path, monkeypatch, conditioned):
    from vcrm import codec_eval, features
    source = episode('val') | {'group': 'fixture:relation'}
    config = {'data_root': str(tmp_path), 'resident_slot_budget': 100, 'keyframe_interval': 3,
              'key_dimensions': 3, 'history_slots': 2, 'state_similarity': .8,
              'read_latent_slots': 10, 'memory_protocol': 'final_current_snapshot_v1'}
    write_json(tmp_path / 'prepared/templama_val.json', [source])
    class Reader:
        cfg, device = config, torch.device('cpu')

        def answer(self, query, bundle):
            return {'answer': 'fixture', 'read_latent_slots': bundle.shape[0],
                    'read_seconds': 0., 'kv_cache_bytes': 0}
    codec = SlotCodec(8, 2, 4, 2, conditioned).eval()
    markers = VersionMarkers(8).eval()
    index = SemanticIndex(8, 3).eval()
    runtime = SlotMemoryRuntime(Reader(), codec, markers, index, CurrentSnapshotStore(codec, 100, 3, 3))
    monkeypatch.setattr(SlotMemoryRuntime, 'from_checkpoint', classmethod(lambda cls, *args: runtime))
    monkeypatch.setattr(features, 'check', lambda *args: None)
    monkeypatch.setattr(features, 'load', lambda cfg, split, eid, event: torch.ones(4, 8) * int(event['id'][-1]))
    root = tmp_path / 'result'
    codec_eval.evaluate(config, root, tmp_path / 'training')
    report = codec_eval.summarize(config, root)
    assert report['complete'] and report['queries'] == 7
    assert report['compressed_history_queries'] == 6
    assert report['auxiliary_anchor_slots_mean'] == 0
    assert report['resident_latent_slots_mean'] == 4 + 6 * 2
    row = read_json(row_path(root, 'episodes', source['id']))
    assert row['roundtrip_equal'] and row['versions'] == 7
    assert all(q['selected_kind'] == 'code' for q in row['queries'] if not q['latest'])
    assert row['write_trace'][0]['online_update_supported'] is False
