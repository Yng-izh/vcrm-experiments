import json

import numpy as np
import pytest
import torch

from vcrm.codec import SlotCodec
from vcrm.data import ingestion_view
from vcrm.refinement import align_final_current
from vcrm.store import CurrentSnapshotStore, KeyframeStore
from vcrm.training import temporal_pairs
from test_slots import episode, event


def test_final_alignment_matches_current_condition_and_negative_answers_without_mutation():
    source = episode()
    for q in source['queries']:
        q['answers'] = ['final', 'shared'] if q['latest'] else ['old', 'shared']
    original = temporal_pairs([source], 3)
    before = json.dumps(original, sort_keys=True)
    pairs = align_final_current(original, [source], True)
    assert {p['id'] for p in pairs} == {p['id'] for p in original}
    assert all(p['latest']['latest'] and p['current']['id'] == 's:6' for p in pairs)
    assert all(p['anchor'] == p['current'] for p in pairs)
    assert all(p['negative_answers'] == ['final'] for p in pairs)
    assert json.dumps(original, sort_keys=True) == before
    assert pairs[0]['old'] == original[0]['old']
    assert all('answers' not in p['anchor'] for p in pairs)


@pytest.mark.parametrize('conditioned', [False, True])
def test_snapshot_encodes_once_against_final_current_and_persists_only_codes(tmp_path, conditioned):
    torch.manual_seed(7)
    codec = SlotCodec(8, 2, 4, 2, conditioned).eval()
    events = ingestion_view(episode())
    memories = {e['id']: torch.ones(4, 8) * (i + 1) for i, e in enumerate(events)}
    keys = {e['id']: np.ones(3) / 3 ** .5 for e in events}
    store = CurrentSnapshotStore(codec, 100, 3, 3)
    receipt = store.build(events, memories, keys)
    assert not receipt['source_features_retained'] and not receipt['online_update_supported']
    assert store.resident_slots() == 4 + 6 * 2
    assert store.current('s')['id'] == 's:6'
    assert [e['id'] for e in store.entries if e['kind'] == 'full'] == ['s:6']
    code = store._entry('s:1')
    assert code['anchor_id'] == ('s:6' if conditioned else None)
    expected = codec.encode(memories['s:1'], memories['s:6'] if conditioned else None).detach().half()
    torch.testing.assert_close(torch.from_numpy(code['payload']), expected)
    path = tmp_path / 'snapshot.memory'
    store.save(path)
    assert path.read_bytes().startswith(b'VCRMSP1\n')
    assert b'Person' not in path.read_bytes()
    restored = CurrentSnapshotStore.load(path, codec, 100)
    assert restored.serialize() == path.read_bytes()
    torch.testing.assert_close(store.decode(code), restored.decode(restored._entry('s:1')))
    with pytest.raises(ValueError, match='format'):
        KeyframeStore.load(path, codec, 100)
    with pytest.raises(RuntimeError, match='rebuild'):
        store.ingest(event(7), torch.ones(4, 8), keys['s:6'])
    with pytest.raises(ValueError, match='fresh'):
        store.build(events, memories, keys)
    assert not hasattr(restored, 'source_memories')


def test_snapshot_enforces_all_event_inputs_and_atomic_budget_failure():
    codec = SlotCodec(8, 2, 4, 2, True).eval()
    events = [event(i) for i in range(3)]
    memories = {e['id']: torch.ones(4, 8) for e in events}
    keys = {e['id']: np.ones(3) for e in events}
    store = CurrentSnapshotStore(codec, 4, 3, 3)
    with pytest.raises(ValueError, match='all original'):
        store.build(events, {events[0]['id']: memories[events[0]['id']]}, keys)
    with pytest.raises(ValueError, match='budget'):
        store.build(events, memories, keys)
    assert store.entries == [] and store.blocks == {}
    with pytest.raises(ValueError, match='original full'):
        store.build(events, memories | {'s:1': torch.ones(2, 8)}, keys)


def test_d_condition_mismatch_is_rejected_on_snapshot_load(tmp_path):
    codec = SlotCodec(8, 2, 4, 2, True).eval()
    events = [event(i) for i in range(3)]
    memories = {e['id']: torch.ones(4, 8) for e in events}
    keys = {e['id']: np.ones(3) for e in events}
    store = CurrentSnapshotStore(codec, 100, 3, 3)
    store.build(events, memories, keys)
    store._entry('s:0')['anchor_id'] = 's:1'
    path = tmp_path / 'bad.memory'
    store.save(path)
    with pytest.raises(ValueError, match='anchor'):
        CurrentSnapshotStore.load(path, codec, 100)
