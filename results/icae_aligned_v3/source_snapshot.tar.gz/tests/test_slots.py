import json

import numpy as np
import pytest
import torch

from vcrm.codec import SlotCodec, VersionMarkers
from vcrm.index import SemanticIndex
from vcrm.store import KeyframeStore
from vcrm.streaming import SpanWriter, split_event
from vcrm.training import distillation_loss, paragraph_samples, sequence_unlikelihood, temporal_pairs


def codec(conditioned=False):
    torch.manual_seed(7)
    return SlotCodec(8, 2, 4, 2, conditioned)


def event(i, state='s'):
    return {'id': f'{state}:{i}', 'state_key': state, 'time': f'{2010+i}-01-01T00:00:00',
            'text': f'Person works at team {i}'}


def write(store, i, state='s'):
    return store.ingest(event(i, state), torch.ones(4, 8) * (i + 1), np.ones(3) / 3 ** .5)


def episode(split='train'):
    events = [event(i) for i in range(7)]
    return {'id': 'episode', 'dataset': 'templama', 'split': split, 'events': events,
            'queries': [{'id': e['id'], 'question': 'Person works at _X_', 'as_of': e['time'],
                         'time': e['time'], 'answers': [str(i), 'shared'], 'state_key': 's',
                         'latest': i == 6} for i, e in enumerate(events)]}


def test_c_d_have_same_trainable_capacity_and_direct_m_outputs():
    c, d = codec(), codec(True)
    assert c.parameter_count() == d.parameter_count()
    old, anchor = torch.randn(4, 8), torch.randn(7, 8)
    for module in (c, d):
        output = module(old, anchor)
        assert output.shape == (2, 8)
        output.square().mean().backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in module.parameters())
    assert torch.equal(c.encode(old, anchor), c.encode(old, -anchor))
    assert not torch.equal(d.encode(old, anchor), d.encode(old, -anchor))


def test_attention_is_not_slotwise_subtraction():
    d = codec(True)
    old, anchor = torch.randn(4, 8), torch.randn(7, 8)
    output = d.encode(old, anchor)
    assert output.shape == (2, 8)
    assert not torch.equal(output, old[:2] - anchor[:2])
    assert torch.isfinite(output).all()


def test_immutable_keyframes_never_rebase_or_recompress(tmp_path):
    d = codec(True)
    store = KeyframeStore(d, 100, 3, 3)
    for i in range(3):
        write(store, i)
    original = store._entry('s:1')['payload'].copy()
    for i in range(3, 8):
        write(store, i)
    assert np.array_equal(original, store._entry('s:1')['payload'])
    assert store._entry('s:1')['anchor_id'] == 's:0'
    assert store._entry('s:4')['anchor_id'] == 's:3'
    assert all(e['compression_count'] == 1 for e in store.entries if e['kind'] == 'code')
    path = tmp_path / 'store.memory'
    store.save(path)
    restored = KeyframeStore.load(path, d, 100)
    assert restored.serialize() == path.read_bytes()
    torch.testing.assert_close(store.decode(store._entry('s:1')), restored.decode(restored._entry('s:1')))
    accounting = store.accounting()
    assert sum(accounting[k] for k in ('memory_bytes', 'index_key_bytes', 'metadata_and_format_bytes')) == path.stat().st_size
    assert b'Person' not in path.read_bytes()
    with pytest.raises(ValueError, match='original'):
        store.ingest(event(8), torch.ones(2, 8), np.ones(3))


def test_slot_eviction_protects_dependencies_and_failed_update_is_atomic():
    store = KeyframeStore(codec(True), 12, 3, 3)
    for i in range(10):
        write(store, i)
        assert store.resident_slots() <= 12
        for entry in store.entries:
            if entry['anchor_id']:
                assert store._entry(entry['anchor_id'])['kind'] == 'full'
    assert store.select_version('s')['id'] == 's:9'
    tiny = KeyframeStore(codec(True), 4, 3, 3)
    write(tiny, 0)
    before = tiny.serialize()
    with pytest.raises(ValueError, match='protected'):
        write(tiny, 1)
    assert before == tiny.serialize()


def test_unrelated_states_fifo_whole_dependency_groups():
    store = KeyframeStore(codec(True), 8, 3, 3)
    for i in range(5):
        write(store, i, state=f's{i}')
    assert [e['state'] for e in store.entries] == ['s3', 's4']


def test_markers_and_anchor_overhead_are_not_free_slots():
    d = codec(True)
    store = KeyframeStore(d, 100, 3, 3)
    for i in range(3):
        write(store, i)
    current, historical = store.current('s'), store._entry('s:1')
    markers = VersionMarkers(8)
    bundle = store.bundle([current, historical], markers, 10)
    assert bundle.shape == (4 + 2 + 2 + 2, 8)
    with pytest.raises(ValueError, match='Decoder slot'):
        store.bundle([current, historical], markers, 9)
    assert not torch.equal(markers(torch.ones(2, 8), 'historical', event(1)['time']),
                           markers(torch.ones(2, 8), 'current', event(1)['time']))


def test_load_rejects_different_codec_or_budget(tmp_path):
    store = KeyframeStore(codec(True), 100, 3, 3)
    write(store, 0)
    path = tmp_path / 'store'
    store.save(path)
    with pytest.raises(ValueError, match='identity'):
        KeyframeStore.load(path, codec(), 100)
    with pytest.raises(ValueError, match='budget'):
        KeyframeStore.load(path, codec(True), 3)


def test_semantic_pooling_and_candidate_not_update():
    index = SemanticIndex(8, 3)
    memory = torch.randn(4, 8)
    torch.testing.assert_close(index(memory), index(memory.flip(0)), atol=1e-6, rtol=1e-5)
    key = index.key(memory)
    result = index.associate(key, [{'id': 'a', 'state': 's', 'key': key}])
    assert result['status'] == 'association_candidate_not_fact_update'
    assert index.associate(key, [{'id': 'a', 'state': 's', 'key': key}, {'id': 'b', 'state': 't', 'key': key}]) is None


class Tokenizer:
    bos_token_id = 1

    def encode(self, text, add_special_tokens=False):
        return list(range(10, 10 + len(text.split())))


def test_span_split_is_exact_and_strips_labels():
    source = event(0) | {'text': ' '.join(str(i) for i in range(21)), 'answers': ['secret']}
    spans = split_event(source, Tokenizer(), 8)
    assert [len(s['input_ids']) for s in spans] == [8, 8, 5]
    assert [i for s in spans for i in s['input_ids']] == Tokenizer().encode(source['text'])
    assert all('answers' not in s and 'question' not in s for s in spans)
    assert [(s['token_start'], s['token_end']) for s in spans] == [(0, 8), (8, 16), (16, 21)]


def test_span_similarity_alone_never_merges_versions():
    class Reader:
        tok = Tokenizer()

        def encode_ids(self, ids):
            return torch.ones(4, 8)

    store = KeyframeStore(codec(True), 100, 3, 3)
    writer = SpanWriter(Reader(), SemanticIndex(8, 3), store, validated_index=True)
    first, second = writer.write(event(0)), writer.write(event(1))
    assert first[0]['state_key'] != second[0]['state_key']
    assert second[0]['association'] is not None
    assert not second[0]['conditional_update_triggered']


def test_paired_supervision_uses_train_only_and_skips_shared_negative():
    pairs = temporal_pairs([episode()], interval=3)
    assert pairs
    assert all('shared' not in p['negative_answers'] for p in pairs)
    assert all(p['historical']['time'] < p['latest']['time'] for p in pairs)
    assert all(p['anchor']['time'] <= p['old']['time'] for p in pairs)
    with pytest.raises(ValueError, match='training'):
        temporal_pairs([episode('val')])
    paragraphs = paragraph_samples([episode(), episode() | {'id': 'other'}])
    assert len(paragraphs) == 14
    assert 'answers' not in paragraphs[0][2]
    assert paragraphs == paragraph_samples([episode(), episode() | {'id': 'other'}])


def test_ce_kl_and_negative_loss_have_finite_student_only_gradients():
    student = torch.randn(1, 3, 7, requires_grad=True)
    teacher = torch.randn(1, 3, 7, requires_grad=True)
    targets = torch.tensor([[1, 3, 5]])
    ce, kl = distillation_loss(student, teacher, targets)
    loss = ce + kl + sequence_unlikelihood(student, targets)
    loss.backward()
    assert torch.isfinite(student.grad).all()
    assert teacher.grad is None
    wrong_confident = torch.full((1, 3, 7), -10.)
    wrong_confident.scatter_(-1, targets.unsqueeze(-1), 10.)
    assert sequence_unlikelihood(wrong_confident, targets) > sequence_unlikelihood(student.detach(), targets)
    ce_same, kl_same = distillation_loss(student, student.detach(), targets)
    assert abs(float(kl_same.detach())) < 1e-5


def test_runtime_temporal_multi_entry_roundtrip(tmp_path):
    from vcrm.runtime import SlotMemoryRuntime
    class Reader:
        cfg = {'state_similarity': .8, 'read_latent_slots': 10}
        device = torch.device('cpu')

        def answer(self, query, bundle=None):
            return {'answer': 'fixture', 'read_latent_slots': 0 if bundle is None else bundle.shape[0]}

    d = codec(True)
    store = KeyframeStore(d, 100, 3, 3)
    for i in range(3):
        write(store, i)
    runtime = SlotMemoryRuntime(Reader(), d, VersionMarkers(8), SemanticIndex(8, 3), store)
    result = runtime.answer({'question': 'Where?', 'state_key': 's', 'as_of': event(1)['time']})
    assert result['selected_entry_ids'] == ['s:2', 's:1']
    assert result['read_latent_slots'] == 10
    assert result['auxiliary_anchor_slots'] == 4
    runtime.save(tmp_path / 'runtime')
    runtime.store = KeyframeStore.load(tmp_path / 'runtime', d, 100)
    restored_result = runtime.answer({'question': 'Where?', 'state_key': 's', 'as_of': event(1)['time']})
    assert {k: v for k, v in restored_result.items() if k != 'codec_recovery_seconds'} == {
        k: v for k, v in result.items() if k != 'codec_recovery_seconds'}
    with pytest.raises(ValueError, match='not calibrated'):
        runtime.answer({'question': 'Where?'})


def test_memory_only_adaptation_freezes_lora_and_task_rows():
    from types import SimpleNamespace
    from vcrm.reader import FrozenReader
    class Network(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.lora_weight = torch.nn.Parameter(torch.ones(3, 3))
            self.memory_token_embed = torch.nn.Embedding(7, 8)

    class Model:
        def gradient_checkpointing_disable(self):
            pass

        def eval(self):
            pass

    reader = FrozenReader.__new__(FrozenReader)
    reader.net, reader.model = Network(), Model()
    parameters = reader.enable_encoder_adaptation()
    assert len(parameters) == 1
    reader.net.memory_token_embed.weight.sum().backward()
    assert reader.net.lora_weight.requires_grad is False
    assert reader.net.lora_weight.grad is None
    assert reader.net.memory_token_embed.weight.grad[:-3].abs().sum() > 0
    assert reader.net.memory_token_embed.weight.grad[-3:].abs().sum() == 0


def test_decoder_context_refreezes_peft_reenabled_lora():
    import contextlib
    from vcrm.reader import FrozenReader
    class Network(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.lora_weight = torch.nn.Parameter(torch.ones(2))
            self.memory_token_embed = torch.nn.Embedding(4, 2)
    network = Network()
    class Model:
        @contextlib.contextmanager
        def disable_adapter(self):
            try:
                yield
            finally:
                network.requires_grad_(True)
    reader = FrozenReader.__new__(FrozenReader)
    reader.net, reader.model, reader.encoder_trainable = network, Model(), False
    with reader.decoder_mode():
        pass
    assert not any(p.requires_grad for p in network.parameters())
    reader.encoder_trainable = True
    with reader.decoder_mode():
        pass
    assert network.memory_token_embed.weight.requires_grad
    assert not network.lora_weight.requires_grad


def test_changed_weights_cannot_read_old_persistent_codes(tmp_path):
    d = codec(True)
    store = KeyframeStore(d, 100, 3, 3)
    write(store, 0)
    store.save(tmp_path / 'store')
    with torch.no_grad():
        d.queries.add_(1)
    with pytest.raises(ValueError, match='weights identity'):
        KeyframeStore.load(tmp_path / 'store', d, 100)


def test_codec_training_rejects_smoke_gate(tmp_path):
    from vcrm.training import validate_codec_gate
    with pytest.raises(RuntimeError, match='manual review'):
        validate_codec_gate({})
    root = tmp_path / 'gate'
    root.mkdir()
    for file, value in [('gate.json', {'decision': 'eligible_for_manual_review'}),
                        ('summary.json', {'complete': True, 'scope': 'smoke'}), ('manifest.json', {})]:
        (root / file).write_text(json.dumps(value))
    with pytest.raises(RuntimeError, match='pilot'):
        validate_codec_gate({'codec_gate_run': 'gate', 'output_root': str(tmp_path), 'codec_manual_review_approved': True})


@pytest.mark.parametrize('conditioned', [False, True])
@pytest.mark.parametrize('snapshot', [False, True])
def test_codec_training_and_checkpoint_runtime_with_small_reader(tmp_path, monkeypatch, conditioned, snapshot):
    from vcrm import reader as reader_module, training
    from vcrm.runtime import SlotMemoryRuntime
    class Reader:
        def __init__(self, config):
            self.cfg, self.device, self.shape = config, torch.device('cpu'), (4, 8)

        def encode_event(self, event):
            value = int(event['id'].split(':')[-1])
            return (torch.arange(32).reshape(4, 8).float() + value) / 10

        def answer_logits(self, query, answer, bundle):
            signal = bundle.mean()
            logits = signal * torch.arange(5).float().reshape(1, 1, 5).expand(1, 2, 5)
            return logits, torch.tensor([[1, 2]])

        def answer(self, query, bundle=None):
            return {'answer': 'fixture', 'read_latent_slots': bundle.shape[0]}

    monkeypatch.setattr(reader_module, 'FrozenReader', Reader)
    monkeypatch.setattr(training, 'validate_codec_gate', lambda config: None)
    folder = tmp_path / 'prepared'
    folder.mkdir()
    source_episode = episode()
    for query in source_episode['queries']:
        query['answers'] = query['answers'][:1]
    (folder / 'templama_train.json').write_text(json.dumps([source_episode]))
    weights = tmp_path / 'base'
    weights.write_bytes(b'fixture')
    root = tmp_path / 'train'
    root.mkdir()
    config = {'allow_training': True, 'data_root': str(tmp_path), 'seed': 42, 'keyframe_interval': 3,
              'history_slots': 2, 'codec_width': 4, 'codec_heads': 2, 'key_dimensions': 3,
              'codec_learning_rate': 1e-3, 'codec_epochs': 1, 'gradient_accumulation': 2,
              'gradient_clip': 1., 'distillation_temperature': 2., 'distillation_weight': 1.,
              'unlikelihood_weight': .1, 'pooled_alignment_weight': .1, 'index_loss_weight': .1,
              'index_negative_margin': .2, 'checkpoint': str(weights), 'model_revision': 'fixture',
              'resident_slot_budget': 100, 'state_similarity': .8, 'read_latent_slots': 10}
    config.update({'codec_epochs': 2, 'codec_lr_schedule': 'warmup_cosine',
                   'contrastive_weight': 1., 'contrastive_margin': 1.5,
                   'decoder_anchor_dropout': .25, 'save_epoch_checkpoints': True,
                   'train_diagnostic_questions': 2})
    if snapshot:
        config.update(memory_protocol='final_current_snapshot_v1', decoder_anchor_dropout=0.)
    result = training.train_codec(config, root, conditioned, limit=1)
    assert result['completed'] and result['steps'] > 0
    assert result['method'] == ('D' if conditioned else 'C')
    assert len(result['epoch_history']) == 2
    assert (root / 'epoch_02.safetensors').exists()
    assert json.loads((root / 'train_evaluation/epoch_02.json').read_text())['queries'] == 2
    assert result['anchor_dropout'] == (.25 if conditioned and not snapshot else 0.)
    runtime = SlotMemoryRuntime.from_checkpoint(config, root)
    if snapshot:
        events = [event(i) for i in range(3)]
        memories = {e['id']: runtime.reader.encode_event(e) for e in events}
        keys = {eid: runtime.index.key(memory) for eid, memory in memories.items()}
        runtime.store.build(events, memories, keys)
        with pytest.raises(RuntimeError, match='incremental'):
            runtime.write_fact(event(3))
        with pytest.raises(ValueError, match='protocol'):
            SlotMemoryRuntime.from_checkpoint(config | {'memory_protocol': 'immutable_keyframe_v1'}, root)
        audit = json.loads((root / 'training_input_audit.json').read_text())
        assert audit['current_policy'] == 'final observed current'
        assert all(row['condition_entry_id'] == row['current_entry_id']
                   for row in map(json.loads, (root / 'loss_history.jsonl').read_text().splitlines()))
    else:
        for i in range(3):
            runtime.write_fact(event(i))
    answer = runtime.answer({'question': 'Where?', 'state_key': 's', 'as_of': event(1)['time']})
    assert answer['read_latent_slots'] == 10
    if snapshot:
        assert answer['auxiliary_anchor_slots'] == 0
    assert runtime.validated_index is False
    path = tmp_path / 'persisted'
    runtime.save(path)
    restored = SlotMemoryRuntime.from_checkpoint(config, root, path)
    assert restored.store.serialize() == path.read_bytes()
