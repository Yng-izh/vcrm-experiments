"""Memory-only adaptation and paired temporal slot-codec training (opt-in)."""
import os
import json
import math
from pathlib import Path
import random
import time

import torch
from torch.nn import functional as F

from .data import ingestion_view, query_view
from .io import digest, file_digest, read_json, write_json
from .metrics import normalize


def adaptation_samples(episodes):
    result = []
    for episode in episodes:
        if episode['split'] != 'train' or episode['dataset'] != 'templama':
            raise ValueError('Only filtered training facts may train adaptation or codecs')
        events = ingestion_view(episode)
        for query in episode['queries']:
            eligible = [e for e in events if e['time'] <= query['as_of']]
            if not eligible:
                raise ValueError('Missing observed version for training query')
            result.append((episode['id'], eligible[-1], query_view(query), query['answers'][0]))
    return result


def paragraph_samples(episodes, seed=42):
    samples = adaptation_samples(episodes)
    facts = [(e['id'], event) for e in episodes for event in ingestion_view(e)]
    rng = random.Random(seed)
    output = []
    for eid, event, query, answer in samples:
        candidates = [(group, fact) for group, fact in facts if group != eid]
        background = rng.sample(candidates, min(3, len(candidates)))
        events = [event] + [fact for _, fact in background]
        rng.shuffle(events)
        text = 'The following observations describe facts recorded at different times.\n\n' + '\n\n'.join(
            f"An observation dated {e['time'][:10]} records the following: {e['text']}" for e in events)
        output.append((eid, text, query, answer))
    return output


def temporal_pairs(episodes, interval=5):
    adaptation_samples(episodes)  # Reject evaluation data before using any labels.
    if interval < 2:
        raise ValueError('Invalid keyframe interval')
    pairs = []
    for episode in episodes:
        events = ingestion_view(episode)
        for current_index in range(2, len(events)):
            old_index = current_index - 1
            if old_index % interval == 0:
                continue  # Keyframes remain full, not codec targets.
            old, current = events[old_index], events[current_index]
            anchor = events[old_index // interval * interval]
            historical = next(q for q in episode['queries'] if q['time'] == old['time'])
            latest = next(q for q in episode['queries'] if q['time'] == current['time'])
            # Shared valid answers are not negative versions.
            negatives = [a for a in latest['answers'] if normalize(a) not in {normalize(v) for v in historical['answers']}]
            pairs.append({'id': episode['id'] + ':' + current['id'], 'state_key': old['state_key'],
                          'old': old, 'current': current, 'anchor': anchor,
                          'historical': historical, 'latest': latest, 'negative_answers': negatives})
    return pairs


def distillation_loss(student, teacher, target, temperature=2.):
    if student.shape != teacher.shape or student.shape[:-1] != target.shape or temperature <= 0:
        raise ValueError('Teacher/student must share answer-prefix positions and vocabulary')
    ce = F.cross_entropy(student.reshape(-1, student.shape[-1]), target.reshape(-1))
    kl = F.kl_div(F.log_softmax(student.float() / temperature, dim=-1),
                  F.softmax(teacher.detach().float() / temperature, dim=-1), reduction='none').sum(-1).mean()
    return ce, kl * temperature ** 2


def sequence_unlikelihood(logits, target):
    # Penalize the complete wrong-answer sequence, not each word shared by versions.
    probabilities = F.log_softmax(logits.float(), dim=-1).gather(-1, target.unsqueeze(-1)).squeeze(-1)
    log_probability = probabilities.sum(-1)
    return -torch.log1p(-log_probability.exp().clamp(max=1. - 1e-6)).mean()


def mean_answer_logprob(logits, target):
    # Reader targets end in EOS; compare answer text tokens, excluding EOS and length bias.
    if logits.shape[:-1] != target.shape or target.shape[-1] < 2:
        raise ValueError('Contrastive answers need at least one text token plus EOS')
    values = F.log_softmax(logits.float()[..., :-1, :], dim=-1)
    return values.gather(-1, target[..., :-1].unsqueeze(-1)).squeeze(-1).mean()


def contrastive_margin(correct, wrong, margin=1.5):
    if margin <= 0:
        raise ValueError('Contrastive margin must be positive')
    return F.relu(margin + wrong - correct)


def cosine_warmup_factor(step, total, warmup):
    if not 0 <= warmup < total or total < 1:
        raise ValueError('Invalid cosine schedule')
    if step < warmup:
        return (step + 1) / max(1, warmup)
    return .5 * (1. + math.cos(math.pi * min(1., (step - warmup) / (total - warmup))))


def train_only(config, limit):
    episodes = read_json(Path(config['data_root']) / 'prepared/templama_train.json')
    return episodes[:limit] if limit else episodes


def save_weights(path, tensors):
    from safetensors.torch import save_file
    path = Path(path)
    temp = path.with_name('.' + path.name + '.partial')
    save_file({k: v.detach().cpu().contiguous() for k, v in tensors.items()}, str(temp))
    os.replace(temp, path)


def adapt_encoder(config, root, limit=None):
    from .reader import FrozenReader
    if config.get('adaptation_protocol') != 'paragraph_memory_only_v1':
        raise RuntimeError('Short-fact adaptation is retired; select paragraph_memory_only_v1 explicitly')
    if not config.get('allow_training'):
        raise RuntimeError('Training disabled; explicitly authorize a new config')
    episodes = train_only(config, limit)
    samples = paragraph_samples(episodes, config['seed'])
    root = Path(root)
    if (root / 'encoder.safetensors').exists():
        raise RuntimeError('Use a new run; optimizer resume is not implemented')
    write_json(root / 'training_input_audit.json', {'protocol': config['adaptation_protocol'],
        'samples': len(samples), 'train_ids': [e['id'] for e in episodes],
        'input_sha256': digest(samples), 'note': 'Synthetic multi-fact paragraphs, not natural-dialogue validation'})
    reader = FrozenReader(config)
    parameters = reader.enable_encoder_adaptation()
    optimizer = torch.optim.AdamW(parameters, lr=config['learning_rate'], weight_decay=0.)
    original_lora = {k: digest(v.detach().cpu().numpy().tobytes()) for k, v in reader.net.named_parameters() if 'lora_' in k}
    task_embeddings = reader.net.memory_token_embed.weight[-3:].detach().clone()
    rng = random.Random(config['seed'])
    steps, started = 0, time.perf_counter()
    accumulation = config['gradient_accumulation']
    for epoch in range(config['epochs']):
        rng.shuffle(samples)
        optimizer.zero_grad(set_to_none=True)
        for i, (_, text, query, answer) in enumerate(samples):
            memory = reader.encode(text, training=True)
            loss = reader.qa_loss(query, answer, memory)
            if not torch.isfinite(loss):
                raise ValueError('Non-finite adaptation loss')
            size = min(accumulation, len(samples) - i // accumulation * accumulation)
            (loss / size).backward()
            if (i + 1) % accumulation == 0 or i + 1 == len(samples):
                norm = torch.nn.utils.clip_grad_norm_(parameters, config['gradient_clip'])
                if not torch.isfinite(norm):
                    raise ValueError('Non-finite adaptation gradient')
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                steps += 1
                print(f'adapt epoch={epoch} step={steps} loss={float(loss.detach()):.4f}', flush=True)
        if not torch.equal(task_embeddings, reader.net.memory_token_embed.weight[-3:].detach()):
            raise AssertionError('Frozen task tokens changed')
        if original_lora != {k: digest(v.detach().cpu().numpy().tobytes()) for k, v in reader.net.named_parameters() if 'lora_' in k}:
            raise AssertionError('Released LoRA changed during memory-only adaptation')
    checkpoint = root / 'encoder.safetensors'
    save_weights(checkpoint, reader.encoder_state())
    result = {'completed': True, 'scope': 'smoke' if limit else 'full_training_split',
              'checkpoint': str(checkpoint), 'checkpoint_sha256': file_digest(checkpoint),
              'base_checkpoint_sha256': file_digest(config['checkpoint']), 'model_revision': config['model_revision'],
              'training_data_sha256': digest(episodes), 'optimizer_steps': steps,
              'training_samples': len(samples), 'trainable_parameters': sum(p.numel() for p in parameters),
              'protocol': config['adaptation_protocol'], 'rank512_lora_unchanged': True,
              'task_tokens_frozen': True, 'decoder_frozen': True, 'seconds': time.perf_counter() - started,
              'note': 'Parameter freezing does not guarantee preservation of long-context performance.'}
    write_json(root / 'adaptation.json', result)
    return result


def train_codec(config, root, conditioned=False, limit=None):
    from .codec import SlotCodec, VersionMarkers
    from .index import SemanticIndex
    from .reader import FrozenReader
    if not config.get('allow_training'):
        raise RuntimeError('Training disabled; explicitly authorize a new config')
    validate_codec_gate(config)
    episodes = train_only(config, limit)
    pairs = temporal_pairs(episodes, config['keyframe_interval'])
    protocol = config.get('memory_protocol', 'immutable_keyframe_v1')
    if protocol not in ('immutable_keyframe_v1', 'final_current_snapshot_v1'):
        raise ValueError('Unknown codec memory protocol')
    if protocol == 'final_current_snapshot_v1':
        from .refinement import align_final_current
        pairs = align_final_current(pairs, episodes, condition_on_current=True)
        if config.get('decoder_anchor_dropout', 0.):
            raise ValueError('Main final-current C/D comparison requires equal regularization: no anchor dropout')
    feature_episode = {event['id']: episode['id'] for episode in episodes for event in ingestion_view(episode)}
    if config.get('use_feature_cache'):
        from .features import check
        check(config, 'train')
    if not pairs:
        raise ValueError('No changed multi-version training pairs; need at least three versions')
    root = Path(root)
    if (root / 'codec.safetensors').exists() or (root / 'loss_history.jsonl').exists():
        raise RuntimeError('Use a new training run; partial optimizer resume is not implemented')
    started = time.perf_counter()
    write_json(root / 'training_input_audit.json', {
        'memory_protocol': protocol, 'training_data_sha256': digest(episodes),
        'pair_ids_sha256': digest(sorted(p['id'] for p in pairs)), 'pair_content_sha256': digest(pairs),
        'pairs': len(pairs), 'negative_supervised_pairs': sum(bool(p['negative_answers']) for p in pairs),
        'current_policy': 'final observed current' if protocol == 'final_current_snapshot_v1' else 'next observed update',
        'condition_policy': 'same final current for encoding and decoding' if protocol == 'final_current_snapshot_v1'
                            else 'immutable historical keyframe',
        'teacher_policy': 'unchanged single uncompressed target entry; not co-injection matched'})
    torch.manual_seed(config['seed'])
    reader = FrozenReader(config)
    dropout = config.get('decoder_anchor_dropout', 0.) if conditioned else 0.
    codec = SlotCodec(reader.shape[1], config['history_slots'], config['codec_width'],
                      config['codec_heads'], conditioned, dropout, config['seed']).to(reader.device)
    markers = VersionMarkers(reader.shape[1]).to(reader.device)
    index = SemanticIndex(reader.shape[1], config['key_dimensions']).to(reader.device)
    parameters = list(codec.parameters()) + list(markers.parameters())
    index_parameters = list(index.parameters())
    optimizer = torch.optim.AdamW(parameters, lr=config['codec_learning_rate'])
    # Separate clipping/optimizer avoids C/D gradient magnitudes changing the
    # otherwise shared index updates and confounding the compression ablation.
    index_optimizer = torch.optim.AdamW(index_parameters, lr=config['codec_learning_rate'])
    rng = random.Random(config['seed'])
    accumulation = config['gradient_accumulation']
    steps = 0
    total_steps = config['codec_epochs'] * math.ceil(len(pairs) / accumulation)
    scheduler = index_scheduler = None
    if config.get('codec_lr_schedule') == 'warmup_cosine':
        warmup = min(total_steps - 1, max(1, int(total_steps * config.get('codec_warmup_fraction', .05))))
        schedule = lambda step: cosine_warmup_factor(step, total_steps, warmup)
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
        index_scheduler = torch.optim.lr_scheduler.LambdaLR(index_optimizer, schedule)
    diagnostic_pairs = []
    if config.get('train_diagnostic_questions', 0):
        from .refinement import fixed_train_pairs
        diagnostic_pairs = fixed_train_pairs(pairs, config['train_diagnostic_questions'], config['seed'], episodes)
        previous_run = config.get('previous_train_diagnostic_run')
        if previous_run:
            if Path(previous_run).name != previous_run:
                raise ValueError('Diagnostic reference must be a run name')
            previous = read_json(Path(config['output_root']) / previous_run / 'train_diagnostic_manifest.json')
            if (previous['pair_ids'] != [p['id'] for p in diagnostic_pairs] or
                    previous['training_data_sha256'] != digest(episodes)):
                raise ValueError('Do not change the fixed 200 train diagnostic questions or underlying data')
        write_json(root / 'train_diagnostic_manifest.json', {
            'pair_ids': [p['id'] for p in diagnostic_pairs], 'training_data_sha256': digest(episodes),
            'seed': config['seed'], 'scope': 'fixed in-sample disjoint-answer conflict pairs',
            'diagnostic_pairs_sha256': digest(diagnostic_pairs),
            'current_policy': 'final observed current version', 'memory_protocol': protocol,
            'optimizer_current_policy': 'final observed current' if protocol == 'final_current_snapshot_v1'
                                        else 'next observed update'})
    epoch_history = []
    def memory_of(event):
        if config.get('use_feature_cache'):
            from .features import load
            return load(config, 'train', feature_episode[event['id']], event).to(reader.device).float()
        return reader.encode_event(event).to(reader.device).float()

    for epoch in range(config['codec_epochs']):
        rng.shuffle(pairs)
        optimizer.zero_grad(set_to_none=True)
        index_optimizer.zero_grad(set_to_none=True)
        epoch_rows = []
        for i, pair in enumerate(pairs):
            current, old, anchor = [memory_of(pair[name])
                                    for name in ('current', 'old', 'anchor')]
            recovered = codec(old, anchor)
            student_bundle = torch.cat((markers(current, 'current', pair['current']['time']),
                                        markers(recovered, 'historical', pair['old']['time'])))
            losses, ce_values, kl_values = [], [], []
            for kind, teacher_memory in (('latest', current), ('historical', old)):
                q = pair[kind]
                visible, answer = query_view(q), q['answers'][0]
                with torch.no_grad():
                    teacher, _ = reader.answer_logits(visible, answer, teacher_memory)
                student, target = reader.answer_logits(visible, answer, student_bundle)
                ce, kl = distillation_loss(student, teacher, target, config['distillation_temperature'])
                losses.append(ce + config['distillation_weight'] * kl)
                ce_values.append(float(ce.detach()))
                kl_values.append(float(kl.detach()))
                if kind == 'historical' and config.get('contrastive_weight', 0):
                    correct_logprob = mean_answer_logprob(student, target)
            unlikelihood = recovered.new_zeros(())
            contrast = recovered.new_zeros(())
            for wrong in pair['negative_answers']:
                logits, target = reader.answer_logits(query_view(pair['historical']), wrong, student_bundle)
                unlikelihood = unlikelihood + sequence_unlikelihood(logits, target)
                if config.get('contrastive_weight', 0):
                    contrast = contrast + contrastive_margin(correct_logprob, mean_answer_logprob(logits, target),
                                                             config.get('contrastive_margin', 1.5))
            if pair['negative_answers']:
                contrast = contrast / len(pair['negative_answers'])
            pooled = 1. - F.cosine_similarity(old.mean(0), recovered.mean(0), dim=0)
            # Same-state train labels supervise the shared pooler; different entity/
            # relation groups are negatives. No benchmark labels are used.
            positive = 1. - (index(old) * index(current)).sum()
            other = next((p for p in pairs if p['state_key'] != pair['state_key']), None)
            negative = recovered.new_zeros(())
            if other is not None:
                distractor = memory_of(other['current'])
                negative = F.relu((index(old) * index(distractor)).sum() - config['index_negative_margin'])
            loss = (sum(losses) / 2 + config['unlikelihood_weight'] * unlikelihood +
                    config['pooled_alignment_weight'] * pooled + config['index_loss_weight'] * (positive + negative) +
                    config.get('contrastive_weight', 0.) * contrast)
            if not torch.isfinite(loss):
                raise ValueError('Non-finite codec loss')
            size = min(accumulation, len(pairs) - i // accumulation * accumulation)
            (loss / size).backward()
            learning_rate = optimizer.param_groups[0]['lr']
            if (i + 1) % accumulation == 0 or i + 1 == len(pairs):
                norm = torch.nn.utils.clip_grad_norm_(parameters, config['gradient_clip'])
                index_norm = torch.nn.utils.clip_grad_norm_(index_parameters, config['gradient_clip'])
                if not torch.isfinite(norm) or not torch.isfinite(index_norm):
                    raise ValueError('Non-finite codec gradients')
                optimizer.step()
                index_optimizer.step()
                if scheduler is not None:
                    scheduler.step()
                    index_scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                index_optimizer.zero_grad(set_to_none=True)
                steps += 1
            progress = {'epoch': epoch + 1, 'epochs': config['codec_epochs'], 'pair': i + 1, 'steps': steps,
                       'loss': float(loss.detach()), 'qa_ce': ce_values, 'teacher_kl': kl_values,
                       'negative_version_loss': float(unlikelihood.detach()), 'contrastive_loss': float(contrast.detach()),
                       'pooled_alignment_loss': float(pooled.detach()), 'index_loss': float((positive + negative).detach()),
                       'learning_rate': learning_rate, 'total_steps': total_steps,
                       'negative_supervised': bool(pair['negative_answers']),
                       'current_entry_id': pair['current']['id'], 'condition_entry_id': pair['anchor']['id'],
                       'elapsed_seconds': time.perf_counter() - started}
            epoch_rows.append(progress)
            write_json(root / 'progress.json', progress)
            with (root / 'loss_history.jsonl').open('a') as handle:
                handle.write(json.dumps(progress) + '\n')
            print(f'codec epoch={epoch} pair={i+1}/{len(pairs)} loss={float(loss.detach()):.4f}', flush=True)
        epoch_result = {'epoch': epoch + 1, 'steps': steps, 'pairs': len(pairs),
                        'mean': {k: sum(r[k] for r in epoch_rows) / len(epoch_rows)
                                 for k in ('loss', 'negative_version_loss', 'contrastive_loss',
                                           'pooled_alignment_loss', 'index_loss')},
                        'qa_ce_mean': [sum(r['qa_ce'][j] for r in epoch_rows) / len(epoch_rows) for j in range(2)],
                        'teacher_kl_mean': [sum(r['teacher_kl'][j] for r in epoch_rows) / len(epoch_rows) for j in range(2)]}
        if diagnostic_pairs:
            from .refinement import train_diagnostic
            write_json(root / 'progress.json', {'phase': 'train_200_diagnostic', 'epoch': epoch + 1, 'steps': steps})
            diagnostic = train_diagnostic(reader, codec, markers, memory_of, diagnostic_pairs)
            write_json(root / 'train_evaluation' / f'epoch_{epoch+1:02d}.json', diagnostic)
            epoch_result['train_conflict_diagnostic'] = {k: v for k, v in diagnostic.items() if k != 'rows'}
            print(f'train-diagnostic epoch={epoch+1} F1={diagnostic["f1"]:.4f} stale={diagnostic["stale_answer"]:.4f}', flush=True)
        epoch_history.append(epoch_result)
        write_json(root / 'epoch_history.json', epoch_history)
        if config.get('save_epoch_checkpoints'):
            tensors = {prefix + '.' + k: v for prefix, module in [('codec', codec), ('markers', markers), ('index', index)]
                       for k, v in module.state_dict().items()}
            save_weights(root / f'epoch_{epoch+1:02d}.safetensors', tensors)
    state = {prefix + '.' + k: v for prefix, module in [('codec', codec), ('markers', markers), ('index', index)]
             for k, v in module.state_dict().items()}
    checkpoint = root / 'codec.safetensors'
    save_weights(checkpoint, state)
    result = {'completed': True, 'scope': 'smoke' if limit else 'full_training_split',
              'method': 'D' if conditioned else 'C', 'checkpoint': str(checkpoint),
              'checkpoint_sha256': file_digest(checkpoint), 'training_data_sha256': digest(episodes),
              'base_checkpoint_sha256': file_digest(config['checkpoint']),
              'adapted_checkpoint_sha256': file_digest(config['adapted_checkpoint']) if config.get('adapted_checkpoint') else None,
              'model_revision': config['model_revision'], 'codec_width': config['codec_width'],
              'codec_heads': config['codec_heads'], 'keyframe_interval': config['keyframe_interval'],
              'reader_sha256': file_digest(Path(__file__).with_name('reader.py')),
              'semantic_index_sha256': digest({k: digest(v.detach().cpu().numpy().tobytes()) for k, v in index.state_dict().items()}),
              'pair_ids_sha256': digest(sorted(p['id'] for p in pairs)), 'pairs': len(pairs),
              'pair_content_sha256': read_json(root / 'training_input_audit.json')['pair_content_sha256'],
              'memory_protocol': protocol, 'seed': config['seed'],
              'codec_parameters': codec.parameter_count(), 'marker_parameters': sum(p.numel() for p in markers.parameters()),
              'index_parameters': sum(p.numel() for p in index.parameters()), 'steps': steps,
              'seconds': time.perf_counter() - started,
              'history_slots': codec.slots, 'role_time_slots_per_entry': 2,
              'anchor_dropout': dropout, 'codec_epochs': config['codec_epochs'], 'epoch_history': epoch_history,
              'learning_rate': config['codec_learning_rate'], 'lr_schedule': config.get('codec_lr_schedule', 'constant'),
              'warmup_fraction': config.get('codec_warmup_fraction'), 'shuffle_each_epoch': True,
              'contrastive_margin': config.get('contrastive_margin'),
              'contrastive_weight': config.get('contrastive_weight', 0.),
              'contrastive_protocol': 'Mean answer text token log-probability excluding EOS; mean over valid negative aliases',
              'anchor_policy': ('final current shared with reader; offline snapshot, not online rebase'
                                if protocol == 'final_current_snapshot_v1' else
                                'immutable keyframe; auxiliary anchor cost is reported separately'),
              'decoder_frozen': True, 'encoder_frozen': True, 'index_validated_for_routing': False,
              'teacher_policy': 'Uncompressed target entry, same gold teacher-forced prefixes; detached logits',
              'loss_weights': {k: config[k] for k in ('distillation_weight', 'unlikelihood_weight',
                                                      'pooled_alignment_weight', 'index_loss_weight')},
              'readability_gate_override': read_json(config['codec_gate_override']) if config.get('codec_gate_override') else None,
              'warning': 'Training completion does not validate readability, retrieval, or research claims.'}
    write_json(root / 'codec_training.json', result)
    return result


def validate_codec_gate(config):
    name = config.get('codec_gate_run')
    override_path = config.get('codec_gate_override')
    if ((not config.get('codec_manual_review_approved') and not override_path) or
            not name or Path(name).name != name):
        raise RuntimeError('Codec training requires a complete readability gate and explicit manual review')
    root = Path(config['output_root']) / name
    gate, summary, manifest = [read_json(root / file) for file in ('gate.json', 'summary.json', 'manifest.json')]
    if not summary.get('complete') or summary.get('scope') != 'validation':
        raise RuntimeError('Partial/pilot or failed readability cannot authorize codec training')
    if override_path:
        override = read_json(override_path)
        if (not override.get('explicit_user_authorization') or not override.get('authorization_note') or
                override.get('gate_run') != name or
                override.get('summary_sha256') != file_digest(root / 'summary.json') or
                override.get('gate_sha256') != file_digest(root / 'gate.json') or
                override.get('original_decision') != gate.get('decision')):
            raise RuntimeError('Invalid or stale explicit user gate override')
    elif gate.get('decision') != 'eligible_for_manual_review':
        raise RuntimeError('Partial/pilot or failed readability cannot authorize codec training')
    previous = manifest['config']
    for key in ('model_revision', 'icae_source_sha256', 'checkpoint', 'adapted_checkpoint'):
        if previous.get(key) != config.get(key):
            raise RuntimeError('Readability gate uses a different reader configuration')
    if manifest['code'].get('vcrm/reader.py') != file_digest(Path(__file__).with_name('reader.py')):
        raise RuntimeError('Reader changed since readability gate')
    for path, sha in manifest['encoder_weights'].items():
        if file_digest(path) != sha:
            raise RuntimeError('Readability checkpoint weights changed')
