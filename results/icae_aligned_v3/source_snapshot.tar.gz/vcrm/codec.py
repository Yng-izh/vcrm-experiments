"""Parameter-matched cross-version slot bottlenecks; no positional subtraction."""
import torch
from torch import nn


class SlotAttention(nn.Module):
    def __init__(self, dimension, width, heads):
        super().__init__()
        self.query = nn.Linear(dimension, width, bias=False)
        self.key = nn.Linear(dimension, width, bias=False)
        self.value = nn.Linear(dimension, width, bias=False)
        self.attention = nn.MultiheadAttention(width, heads, dropout=0., batch_first=True)
        self.output = nn.Linear(width, dimension, bias=False)

    def forward(self, query, context):
        output, _ = self.attention(self.query(query), self.key(context), self.value(context), need_weights=False)
        return self.output(output)


class SlotCodec(nn.Module):
    """C self-aligns old memory; D aligns against a supplied condition memory.

    The runtime protocol chooses immutable keyframe or final-current snapshot.

    Both allocate AND train the same modules. C is a capacity-matched independent
    codec, not the deliberately smaller one-layer pooling baseline.
    """
    def __init__(self, dimension=4096, slots=16, width=256, heads=4, conditioned=False,
                 anchor_dropout=0., dropout_seed=42):
        super().__init__()
        if min(dimension, slots, width, heads) < 1 or width % heads:
            raise ValueError('Invalid slot codec dimensions')
        self.dimension, self.slots, self.conditioned = dimension, slots, conditioned
        if not 0 <= anchor_dropout < 1:
            raise ValueError('Anchor dropout must be in [0, 1)')
        self.anchor_dropout = anchor_dropout
        self.dropout_seed = dropout_seed
        self._dropout_rng = None
        self.queries = nn.Parameter(torch.randn(slots, dimension) * .02)
        self.recovery_queries = nn.Parameter(torch.randn(slots, dimension) * .02)
        self.norm = nn.LayerNorm(dimension)
        self.alignment = SlotAttention(dimension, width, heads)
        self.gate = nn.Sequential(nn.Linear(2 * dimension, width), nn.GELU(), nn.Linear(width, dimension))
        self.compress = SlotAttention(dimension, width, heads)
        self.recover = SlotAttention(dimension, width, heads)

    def _input(self, memory):
        if memory is None or memory.ndim != 2 or memory.shape[1] != self.dimension or not memory.shape[0]:
            raise ValueError('Expected nonempty [slots, hidden] memory')
        if not torch.isfinite(memory).all():
            raise ValueError('Non-finite codec input')
        parameter = self.queries
        return memory.to(device=parameter.device, dtype=parameter.dtype).unsqueeze(0)

    def encode(self, old, anchor=None):
        old = self._input(old)
        context = self._input(anchor) if self.conditioned else old
        aligned = self.alignment(self.norm(old), self.norm(context))
        gate = torch.sigmoid(self.gate(torch.cat((old, aligned), dim=-1)))
        difference = old - gate * aligned
        query = self.queries.unsqueeze(0)
        return (query + self.compress(query, difference))[0]

    def decode(self, code, anchor=None):
        code = self._input(code)
        if code.shape[1] != self.slots:
            raise ValueError('Code must have exactly m slots; recompression is forbidden')
        context = code
        if self.conditioned:
            base = self._input(anchor)
            if self.training and self.anchor_dropout:
                # A separate stream keeps C/D shuffle, initialization and reader RNG matched.
                if self._dropout_rng is None:
                    self._dropout_rng = torch.Generator(device=base.device).manual_seed(self.dropout_seed)
                keep = torch.rand((1, base.shape[1], 1), device=base.device,
                                  generator=self._dropout_rng) >= self.anchor_dropout
                base = base * keep  # Whole slots are zeroed; no inverted-dropout scaling.
            context = torch.cat((base, code), dim=1)
        query = self.recovery_queries.unsqueeze(0)
        # Recovery is m -> m. Restoring 128 tokens is NOT the main protocol.
        return (code + self.recover(query, context))[0]

    def forward(self, old, anchor=None):
        return self.decode(self.encode(old, anchor), anchor)

    def parameter_count(self):
        return sum(p.numel() for p in self.parameters())

    def signature(self):
        import hashlib
        value = hashlib.sha256()
        value.update(str((self.dimension, self.slots, self.conditioned)).encode())
        for name, tensor in sorted(self.state_dict().items()):
            value.update(name.encode())
            value.update(tensor.detach().cpu().float().contiguous().numpy().tobytes())
        return value.hexdigest()


class VersionMarkers(nn.Module):
    """Two extra decoder slots per entry: role prefix and smooth time suffix."""
    def __init__(self, dimension=4096):
        super().__init__()
        self.roles = nn.Parameter(torch.randn(2, dimension) * .02)
        self.time_projection = nn.Linear(4, dimension, bias=False)

    def forward(self, memory, role, timestamp):
        from datetime import datetime
        if role not in ('current', 'historical'):
            raise ValueError('Unknown version role')
        date = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        values = self.roles.new_tensor([(date.year - 2000) / 100., date.month / 12.,
                                        date.day / 31., (date.hour + date.minute / 60.) / 24.])
        memory = memory.to(self.roles)
        return torch.cat((self.roles[int(role == 'historical')].unsqueeze(0), memory,
                          self.time_projection(values).unsqueeze(0)))


class VersionCodec:
    def __init__(self, *args, **kwargs):
        raise RuntimeError('The TransMem difference/MSE codec is retired. Validate independent ICAE entries first; '
                           'the version-conditioned QA codec has not been defined or trained.')
